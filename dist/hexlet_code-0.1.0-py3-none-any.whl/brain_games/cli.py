"""Hello."""
import prompt


# noinspection TaskProblemsInspection
def welcome_user():
    """ddfdf."""
    name = prompt.string('May I have your name? ')
    template = 'Hello, {}!'
    # noinspection TaskProblemsInspection
    print(template.format(name))


# noinspection TaskProblemsInspection
if __name__ == '__main__':
    welcome_user()
